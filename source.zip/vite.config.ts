import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";

// Provided by the build environment's externalize-deps plugin.
// Declare it so TypeScript won't complain when we call it below.
declare function __nbIsExcluded(id: string): boolean;

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
  },
  plugins: [
    react()].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  build: {
    rollupOptions: {
      // Ensure ESM-only packages that cannot be loaded via `require` are NOT marked external
      // so Vite/Rollup will bundle them as ESM instead of attempting a CJS `require` at runtime.
      external: (id: string) => {
        const esOnly = ['lovable-tagger'];
        if (esOnly.includes(id)) return false;
        // When available, delegate to the platform helper which decides other exclusions.
        if (typeof __nbIsExcluded === 'function') return __nbIsExcluded(id);
        return false;
      },
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom', 'react-router-dom'],
          'ui-vendor': ['lucide-react', '@radix-ui/react-dialog', '@radix-ui/react-dropdown-menu'],
        }
      }
    },
    // Optimize chunks for better performance
    chunkSizeWarningLimit: 1000,
    minify: 'esbuild',
  }
}));