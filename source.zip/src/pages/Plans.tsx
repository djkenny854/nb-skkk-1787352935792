
import { FeaturedPackages } from '@/components/FeaturedPackages';
import { SubscriptionProgress } from '@/components/SubscriptionProgress';
import { ResponsiveLayout } from '@/components/ResponsiveLayout';
import { useAuth } from '@/hooks/useAuth';

export default function Plans() {
  const { user } = useAuth();

  return (
    <ResponsiveLayout>
      <div className="space-y-8 pb-20">
        <div className="text-center px-4">
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">Subscription Plans</h1>
          <p className="text-muted-foreground">Choose the perfect plan for your betting success</p>
        </div>
        
        {/* Show subscription progress for authenticated users */}
        {user && <SubscriptionProgress />}
        
        <div className="px-4">
          <FeaturedPackages />
        </div>
      </div>
    </ResponsiveLayout>
  );
}
