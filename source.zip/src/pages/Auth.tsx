import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Eye, EyeOff, User, Mail, Phone, Lock } from 'lucide-react';
import { Navigate, Link } from 'react-router-dom';
import { GoogleSignInButton } from '@/components/GoogleSignInButton';
import { LoadingSpinner, ButtonSpinner } from '@/components/LoadingSpinner';
import kalasoLogo from '@/assets/kalaso-logo.png';

const countries = [
  { code: '+256', name: 'Uganda', flag: '🇺🇬' },
  { code: '+254', name: 'Kenya', flag: '🇰🇪' },
  { code: '+255', name: 'Tanzania', flag: '🇹🇿' },
];

export default function Auth() {
  const { signIn, signUp, resetPassword, user, loading: authLoading } = useAuth();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup' | 'forgot'>('signin');
  const [agreeToTerms, setAgreeToTerms] = useState(false);

  // Sign In Form State
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');

  // Sign Up Form State
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [confirmSignUpPassword, setConfirmSignUpPassword] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [countryCode, setCountryCode] = useState('+256');

  // Forgot Password State
  const [forgotEmail, setForgotEmail] = useState('');

  // Show loading while auth is initializing
  if (authLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <LoadingSpinner size="xl" variant="gradient" text="Loading..." />
      </div>
    );
  }

  // Redirect if already logged in
  if (user) {
    return <Navigate to="/app" replace />;
  }

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    console.log('Attempting login with email:', signInEmail);
    const { error } = await signIn(signInEmail, signInPassword);
    if (error) {
      console.error('Login error:', error);
    }
    setLoading(false);
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!agreeToTerms) {
      return;
    }
    
    if (signUpPassword !== confirmSignUpPassword) {
      return;
    }
    
    setLoading(true);
    const cleanPhone = phone.replace(/\D/g, '');
    const fullPhone = `${countryCode}${cleanPhone}`;
    
    const { error } = await signUp(signUpEmail, signUpPassword, username, fullPhone);

    if (!error) {
      setSignUpEmail('');
      setSignUpPassword('');
      setConfirmSignUpPassword('');
      setUsername('');
      setPhone('');
      setAgreeToTerms(false);
    }
    setLoading(false);
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await resetPassword(forgotEmail);
    if (!error) {
      setAuthMode('signin');
      setForgotEmail('');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Main Content */}
      <div className="flex-1 flex flex-col lg:flex-row">
        {/* Left Side - Logo (hidden on mobile, shown on desktop) */}
        <div className="hidden lg:flex lg:w-1/2 items-center justify-center p-8">
          <img 
            src={kalasoLogo} 
            alt="Kalaso Football Predictions" 
            className="w-[420px] h-auto object-contain"
          />
        </div>

        {/* Right Side - Auth Content */}
        <div className="flex-1 flex flex-col justify-center items-center lg:items-start px-6 py-8 lg:px-16 lg:py-12 lg:w-1/2">
          {/* Mobile Logo */}
          <div className="lg:hidden flex justify-center mb-8">
            <img 
              src={kalasoLogo} 
              alt="Kalaso Football Predictions" 
              className="w-48 h-auto object-contain"
            />
          </div>

          {/* Main Heading */}
          <h1 className="text-3xl lg:text-6xl font-bold text-white mb-4 lg:mb-10 tracking-tight text-center lg:text-left">
            Winning tips daily
          </h1>

          {/* Sub Heading */}
          <h2 className="text-lg lg:text-3xl font-bold text-white mb-6 lg:mb-8 text-center lg:text-left">
            {authMode === 'signin' ? 'Sign in to continue.' : authMode === 'signup' ? 'Join today.' : 'Reset your password.'}
          </h2>

          {/* Auth Forms Container */}
          <div className="max-w-[300px] w-full mx-auto lg:mx-0">
            {authMode === 'forgot' ? (
              <div className="space-y-4">
                <form onSubmit={handleForgotPassword} className="space-y-4">
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    className="h-12 bg-transparent border-2 border-muted-foreground/30 text-foreground placeholder:text-muted-foreground focus:border-primary"
                    required
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full h-9 bg-white hover:bg-gray-200 text-black font-bold rounded-full text-sm"
                    disabled={loading}
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <ButtonSpinner className="border-black border-t-transparent" />
                        Sending...
                      </span>
                    ) : "Send reset link"}
                  </Button>
                  
                  <Button 
                    type="button" 
                    variant="outline"
                    className="w-full h-9 bg-transparent border border-gray-600 text-white hover:bg-white/10 font-bold rounded-full text-sm"
                    onClick={() => setAuthMode('signin')}
                  >
                    Back to Sign in
                  </Button>
                </form>
              </div>
            ) : authMode === 'signin' ? (
              <div className="space-y-4">
                <GoogleSignInButton />
                
                {/* Divider */}
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-gray-700" />
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="bg-black px-4 text-gray-500">or</span>
                  </div>
                </div>
                
                <form onSubmit={handleSignIn} className="space-y-4">
                  <Input
                    type="email"
                    placeholder="Email"
                    value={signInEmail}
                    onChange={(e) => setSignInEmail(e.target.value)}
                    className="h-12 bg-transparent border-2 border-muted-foreground/30 text-foreground placeholder:text-muted-foreground focus:border-primary"
                    required
                  />
                  
                  <div className="relative">
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Password"
                      value={signInPassword}
                      onChange={(e) => setSignInPassword(e.target.value)}
                      className="h-12 bg-transparent border-2 border-muted-foreground/30 text-foreground placeholder:text-muted-foreground pr-12 focus:border-primary"
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-1 top-1/2 -translate-y-1/2 h-10 w-10 p-0 text-muted-foreground hover:text-foreground hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full h-9 bg-white hover:bg-gray-200 text-black font-bold rounded-full text-sm"
                    disabled={loading}
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <ButtonSpinner className="border-black border-t-transparent" />
                        Signing in...
                      </span>
                    ) : "Sign in"}
                  </Button>
                </form>
                
                <Button 
                  type="button" 
                  variant="link"
                  className="w-full p-0 h-auto text-blue-500 hover:text-blue-400 text-sm"
                  onClick={() => setAuthMode('forgot')}
                >
                  Forgot password?
                </Button>

                {/* Don't have account section */}
                <div className="pt-8">
                  <p className="text-gray-500 mb-4 text-base">Don't have an account?</p>
                  <Button 
                    type="button"
                    variant="outline"
                    className="w-full h-9 bg-transparent border border-blue-500 text-blue-500 hover:bg-blue-500/10 font-bold rounded-full text-sm"
                    onClick={() => setAuthMode('signup')}
                  >
                    Create account
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <GoogleSignInButton />
                
                {/* Divider */}
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-gray-700" />
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="bg-black px-4 text-gray-500">or</span>
                  </div>
                </div>
                
                <form onSubmit={handleSignUp} className="space-y-3">
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="text"
                      placeholder="Username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="h-12 pl-11 bg-transparent border-2 border-muted-foreground/30 text-foreground placeholder:text-muted-foreground focus:border-primary"
                      required
                    />
                  </div>

                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="email"
                      placeholder="Email"
                      value={signUpEmail}
                      onChange={(e) => setSignUpEmail(e.target.value)}
                      className="h-12 pl-11 bg-transparent border-2 border-muted-foreground/30 text-foreground placeholder:text-muted-foreground focus:border-primary"
                      required
                    />
                  </div>

                  <div className="flex gap-2">
                    <Select value={countryCode} onValueChange={setCountryCode}>
                      <SelectTrigger className="w-24 h-12 bg-transparent border-2 border-muted-foreground/30 text-foreground rounded-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-background border-border">
                        {countries.map((country) => (
                          <SelectItem 
                            key={country.code} 
                            value={country.code}
                            className="text-foreground hover:bg-muted"
                          >
                            {country.flag} {country.code}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="relative flex-1">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="tel"
                        placeholder="Phone number"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="h-12 pl-11 bg-transparent border-2 border-muted-foreground/30 text-foreground placeholder:text-muted-foreground focus:border-primary"
                        required
                      />
                    </div>
                  </div>

                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Password"
                      value={signUpPassword}
                      onChange={(e) => setSignUpPassword(e.target.value)}
                      className="h-12 pl-11 pr-12 bg-transparent border-2 border-muted-foreground/30 text-foreground placeholder:text-muted-foreground focus:border-primary"
                      required
                      minLength={6}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-1 top-1/2 -translate-y-1/2 h-10 w-10 p-0 text-muted-foreground hover:text-foreground hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>

                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Confirm password"
                      value={confirmSignUpPassword}
                      onChange={(e) => setConfirmSignUpPassword(e.target.value)}
                      className={`h-12 pl-11 bg-transparent border-2 text-foreground placeholder:text-muted-foreground ${
                        confirmSignUpPassword && signUpPassword !== confirmSignUpPassword 
                          ? 'border-destructive focus:border-destructive' 
                          : 'border-muted-foreground/30 focus:border-primary'
                      }`}
                      required
                      minLength={6}
                    />
                  </div>
                  {confirmSignUpPassword && signUpPassword !== confirmSignUpPassword && (
                    <p className="text-xs text-red-500">Passwords do not match</p>
                  )}

                  {/* Terms */}
                  <div className="flex items-start space-x-2 py-2">
                    <Checkbox
                      id="terms"
                      checked={agreeToTerms}
                      onCheckedChange={(checked) => setAgreeToTerms(checked as boolean)}
                      className="mt-0.5 border-gray-600 data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
                    />
                    <label
                      htmlFor="terms"
                      className="text-xs text-gray-400 leading-relaxed cursor-pointer"
                    >
                      By signing up, you agree to the{' '}
                      <Link to="/terms" className="text-blue-500 hover:underline">
                        Terms of Service
                      </Link>
                      {' '}and{' '}
                      <span className="text-blue-500 hover:underline cursor-pointer">
                        Privacy Policy
                      </span>
                    </label>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full h-9 bg-white hover:bg-gray-200 text-black font-bold rounded-full text-sm disabled:opacity-50"
                    disabled={loading || !agreeToTerms}
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <ButtonSpinner className="border-black border-t-transparent" />
                        Creating account...
                      </span>
                    ) : "Create account"}
                  </Button>
                </form>
                
                {/* Already have account section */}
                <div className="pt-6">
                  <p className="text-gray-500 mb-4 text-base">Already have an account?</p>
                  <Button 
                    type="button"
                    variant="outline"
                    className="w-full h-9 bg-transparent border border-blue-500 text-blue-500 hover:bg-blue-500/10 font-bold rounded-full text-sm"
                    onClick={() => setAuthMode('signin')}
                  >
                    Sign in
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="px-6 py-4 lg:px-16">
        <nav className="flex flex-wrap justify-center gap-x-4 gap-y-2 text-xs text-gray-500">
          <Link to="/help" className="hover:underline">Help Centre</Link>
          <Link to="/terms" className="hover:underline">Terms of Service</Link>
          <span className="hover:underline cursor-pointer">Privacy Policy</span>
          <Link to="/contact" className="hover:underline">Contact</Link>
          <span>© 2026 Kalaso Football Predictions</span>
        </nav>
      </footer>
    </div>
  );
}
