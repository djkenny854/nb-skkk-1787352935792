import { useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import confetti from 'canvas-confetti';
import { useUnseenWins } from './useUnseenWins';

const UNSEEN_WIN_IDS_KEY = 'sk_unseen_win_ids';

export function useWinCelebration() {
  const { user } = useAuth();
  const previousWonIdsRef = useRef<Set<string>>(new Set());
  const isInitializedRef = useRef(false);
  
  // Use the unseen wins hook to check for wins when user returns
  const { checkUnseenWins } = useUnseenWins();

  // Trigger confetti celebration
  const triggerCelebration = useCallback(() => {
    // Fire confetti from both sides
    const duration = 3000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    const interval = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);

      // Confetti from left side
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
        colors: ['#22c55e', '#16a34a', '#15803d', '#facc15', '#fbbf24'],
      });

      // Confetti from right side
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
        colors: ['#22c55e', '#16a34a', '#15803d', '#facc15', '#fbbf24'],
      });
    }, 250);

    // Also trigger haptic feedback if available
    if ('vibrate' in navigator) {
      navigator.vibrate([100, 50, 100, 50, 200]);
    }
  }, []);

  // Listen for ticket status changes to 'won' in real-time
  useEffect(() => {
    if (!user) return;

    // First, fetch initial won tickets to avoid false triggers on page load
    const initializeWonTickets = async () => {
      const { data } = await supabase
        .from('tickets')
        .select('id')
        .eq('status', 'won');
      
      if (data) {
        data.forEach(ticket => previousWonIdsRef.current.add(ticket.id));
      }
      isInitializedRef.current = true;
    };

    initializeWonTickets();

    // Subscribe to realtime updates
    const channel = supabase
      .channel('win-celebration-channel')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'tickets',
          filter: 'status=eq.won'
        },
        (payload) => {
          if (!isInitializedRef.current) return;
          
          const ticketId = payload.new.id;
          const oldStatus = payload.old?.status;
          
          // Only trigger if this is a NEW win (not already in our set)
          if (!previousWonIdsRef.current.has(ticketId) && oldStatus !== 'won') {
            console.log('🎉 Win detected! Triggering confetti celebration...');
            previousWonIdsRef.current.add(ticketId);
            
            // Also store in localStorage for persistence
            const storedIds = localStorage.getItem(UNSEEN_WIN_IDS_KEY);
            const unseenIds = storedIds ? JSON.parse(storedIds) : [];
            if (!unseenIds.includes(ticketId)) {
              unseenIds.push(ticketId);
              localStorage.setItem(UNSEEN_WIN_IDS_KEY, JSON.stringify(unseenIds));
            }
            
            triggerCelebration();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, triggerCelebration]);

  return {
    triggerCelebration,
    checkUnseenWins
  };
}
