
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface TicketMatch {
  id: string;
  match_name: string;
  match_time: string;
  prediction: string;
  odds: string;
}

interface TicketHistory {
  id: string;
  ticket_name: string;
  package_id: string;
  status: string;
  comments: string | null;
  betika_link: string | null;
  betpawa_link: string | null;
  created_at: string;
  updated_at: string;
  package_name: string;
  matches: TicketMatch[];
}

export function useTicketsHistory() {
  const { user } = useAuth();
  const [ticketsHistory, setTicketsHistory] = useState<TicketHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchTicketsHistory();
    }
  }, [user]);

  const fetchTicketsHistory = async () => {
    if (!user) return;

    try {
      console.log('🎫 Fetching ticket history for user:', user.id);
      
      // Get the earliest subscription start date
      const { data: subscriptions, error: subError } = await supabase
        .from('user_subscriptions')
        .select('start_date, package_id')
        .eq('user_id', user.id)
        .order('start_date', { ascending: true });

      if (subError) {
        console.error('❌ Error fetching subscriptions:', subError);
        setTicketsHistory([]);
        setLoading(false);
        return;
      }

      if (!subscriptions || subscriptions.length === 0) {
        console.log('📦 No subscriptions found');
        setTicketsHistory([]);
        setLoading(false);
        return;
      }

      const earliestSubscription = subscriptions[0];
      const packageIds = [...new Set(subscriptions.map(sub => sub.package_id))];

      // Get tickets from subscription start date for all packages user ever had
      const { data: ticketsData, error: ticketsError } = await supabase
        .from('tickets')
        .select(`
          id,
          ticket_name,
          package_id,
          status,
          comments,
          betika_link,
          betpawa_link,
          created_at,
          updated_at,
          packages!inner(name)
        `)
        .in('package_id', packageIds)
        .gte('created_at', earliestSubscription.start_date)
        .order('created_at', { ascending: false });

      if (ticketsError) {
        console.error('❌ Error fetching ticket history:', ticketsError);
        setTicketsHistory([]);
        setLoading(false);
        return;
      }

      // Get matches for each ticket
      const ticketsWithMatches = await Promise.all(
        (ticketsData || []).map(async (ticket) => {
          const { data: matchesData, error: matchesError } = await supabase
            .from('ticket_matches')
            .select(`
              id,
              match_name,
              match_time,
              prediction,
              odds
            `)
            .eq('ticket_id', ticket.id)
            .order('match_time', { ascending: true });

          if (matchesError) {
            console.error('❌ Error fetching matches for ticket:', ticket.id, matchesError);
            return {
              ...ticket,
              package_name: ticket.packages?.name || 'Unknown Package',
              matches: []
            };
          }

          return {
            ...ticket,
            package_name: ticket.packages?.name || 'Unknown Package',
            matches: matchesData || []
          };
        })
      );

      console.log('🎫 Ticket history fetched:', ticketsWithMatches.length, 'tickets');
      setTicketsHistory(ticketsWithMatches);
    } catch (error) {
      console.error('💥 Error fetching ticket history:', error);
      setTicketsHistory([]);
    }
    setLoading(false);
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'won':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'lost':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      case 'pending':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'won':
        return '🏆';
      case 'lost':
        return '❌';
      case 'pending':
        return '⏳';
      default:
        return '📝';
    }
  };

  return {
    ticketsHistory,
    loading,
    getStatusColor,
    getStatusIcon,
    refetch: fetchTicketsHistory
  };
}
