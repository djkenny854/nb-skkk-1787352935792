import { useState, useCallback, useRef, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export type NylonPaymentStatus = "idle" | "pending" | "completed" | "failed";

interface InitiateArgs {
  userId: string;
  packageId: string;
  amount: number;
  phoneNumber: string;
  durationDays?: number;
  description?: string;
}

export function useNylonPayment() {
  const { toast } = useToast();
  const [status, setStatus] = useState<NylonPaymentStatus>("idle");
  const [reference, setReference] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [initiating, setInitiating] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const stopPolling = useCallback(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    }
  }, []);

  useEffect(() => () => stopPolling(), [stopPolling]);

  const applyStatus = useCallback((raw: string | null | undefined, err?: string | null) => {
    const s = (raw || "").toLowerCase();
    if (s === "completed" || s === "successful" || s === "success") {
      setStatus("completed");
      stopPolling();
      toast({ title: "Payment Successful 🎉", description: "Your subscription is now active." });
      return true;
    }
    if (s === "failed" || s === "cancelled" || s === "expired") {
      setStatus("failed");
      setErrorMsg(err || "Payment was not completed.");
      stopPolling();
      toast({ title: "Payment Failed", description: err || "Please try again.", variant: "destructive" });
      return true;
    }
    return false;
  }, [stopPolling, toast]);

  const beginTracking = useCallback((ref: string) => {
    // Realtime subscription
    const channel = supabase
      .channel(`nylonpay-${ref}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "nylonpay_transactions", filter: `reference=eq.${ref}` },
        (payload: any) => {
          applyStatus(payload.new?.status, payload.new?.error);
        }
      )
      .subscribe();
    channelRef.current = channel;

    // Polling fallback every 3s. The edge function verifies pending rows with Nylon Pay directly.
    pollRef.current = setInterval(async () => {
      const { data } = await supabase.functions.invoke("check-nylonpay-status", {
        body: { reference: ref },
      });
      if (data?.success) applyStatus(data.status, data.error);
    }, 3000);
  }, [applyStatus]);

  const initiate = useCallback(async (args: InitiateArgs) => {
    setInitiating(true);
    setStatus("idle");
    setErrorMsg(null);
    setReference(null);

    const MAX_ATTEMPTS = 3;
    let lastError: any = null;

    try {
      for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
        try {
          const { data, error } = await supabase.functions.invoke("initiate-nylonpay-payment", {
            body: args,
          });
          if (error) throw new Error(error.message || "Failed to initiate payment");
          if (!data?.success || !data?.reference) throw new Error(data?.error || "Payment initiation failed");

          setReference(data.reference);
          setStatus("pending");
          beginTracking(data.reference);
          toast({
            title: "Check your phone",
            description: "Approve the payment prompt on your mobile device.",
          });
          return { reference: data.reference as string };
        } catch (e: any) {
          lastError = e;
          const msg = String(e?.message || "");
          // Don't retry genuine validation problems
          if (/invalid|missing|not found|must be/i.test(msg)) break;
          if (attempt < MAX_ATTEMPTS) {
            console.warn(`Payment initiation attempt ${attempt} failed, retrying...`, msg);
            await new Promise((r) => setTimeout(r, attempt * 1200));
          }
        }
      }

      setStatus("failed");
      setErrorMsg(lastError?.message || "Payment failed");
      toast({
        title: "Payment Error",
        description: lastError?.message || "Failed to start payment. Please try again.",
        variant: "destructive",
      });
      throw lastError ?? new Error("Payment failed");
    } finally {
      setInitiating(false);
    }
  }, [beginTracking, toast]);

  const reset = useCallback(() => {
    stopPolling();
    setStatus("idle");
    setReference(null);
    setErrorMsg(null);
  }, [stopPolling]);

  return { initiate, reset, status, reference, errorMsg, initiating };
}
