import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

interface Transaction {
  id: string;
  created_at: string;
  amount_ugx: number;
  status: string;
  payment_method: string | null;
  merchant_reference: string;
  package_name: string;
  user_name: string;
  description: string;
}

export function useTransactions() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchTransactions();
    }
  }, [user]);

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('nylonpay_transactions')
        .select(`
          id,
          created_at,
          amount_ugx,
          status,
          method,
          reference,
          description,
          packages(name)
        `)
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching transactions:', error);
        return;
      }

      // Transform the data to match expected format
      const formattedTransactions = data?.map((transaction: any) => ({
        id: transaction.id,
        created_at: transaction.created_at,
        amount_ugx: transaction.amount_ugx,
        status: transaction.status,
        payment_method: transaction.method || 'Mobile Money',
        merchant_reference: transaction.reference,
        package_name: transaction.packages?.name || 'Unknown Package',
        user_name: 'User',
        description: transaction.description || 'Subscription payment'
      })) || [];

      setTransactions(formattedTransactions);
    } catch (error) {
      console.error('Error in fetchTransactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    const normalizedStatus = status.toLowerCase();
    switch (normalizedStatus) {
      case 'completed':
        return '✅';
      case 'cancelled':
      case 'failed':
        return '❌';
      case 'pending':
        return '⏳';
      case 'expired':
        return '⏰';
      default:
        return '❓';
    }
  };

  const getStatusColor = (status: string) => {
    const normalizedStatus = status.toLowerCase();
    switch (normalizedStatus) {
      case 'completed':
        return 'text-green-600 bg-green-100';
      case 'cancelled':
        return 'text-orange-600 bg-orange-100';
      case 'failed':
        return 'text-red-600 bg-red-100';
      case 'pending':
        return 'text-yellow-600 bg-yellow-100';
      case 'expired':
        return 'text-gray-600 bg-gray-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  return {
    transactions,
    loading,
    getStatusIcon,
    getStatusColor,
    refetch: fetchTransactions
  };
}