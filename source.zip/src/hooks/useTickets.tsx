
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { hasAccess } from '@/lib/subscription';

interface TicketMatch {
  id: string;
  match_name: string;
  match_time: string;
  prediction: string;
  odds: string;
}

interface Ticket {
  id: string;
  ticket_name: string;
  package_id: string;
  status: string;
  comments: string | null;
  betika_link: string | null;
  betpawa_link: string | null;
  created_at: string;
  updated_at: string;
  package_name: string;
  matches: TicketMatch[];
}

export function useTickets() {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchTickets();
    const cleanup = setupRealtimeSubscription();
    return cleanup;
  }, [user]);

  const fetchTickets = async () => {
    if (!user) return;

    try {
      console.log('🎫 Fetching tickets for user:', user.id);
      
      // Get the earliest subscription start date and active subscriptions
      const { data: subscriptions, error: subError } = await supabase
        .from('user_subscriptions')
        .select('package_id, start_date, end_date, is_active, packages(grace_period_days)')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .gte('end_date', new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString())
        .order('start_date', { ascending: true });

      if (subError) {
        console.error('❌ Error fetching subscriptions:', subError);
        setTickets([]);
        setLoading(false);
        return;
      }

      const accessibleSubs = (subscriptions || []).filter((s: any) => hasAccess(s));

      if (accessibleSubs.length === 0) {
        console.log('📦 No active subscriptions found');
        setTickets([]);
        setLoading(false);
        return;
      }

      const earliestSubscription = accessibleSubs[0];
      const packageIds = accessibleSubs.map((sub: any) => sub.package_id);

      // Get tickets for subscribed packages ONLY from subscription start date
      const { data: ticketsData, error: ticketsError } = await supabase
        .from('tickets')
        .select(`
          id,
          ticket_name,
          package_id,
          status,
          comments,
          betika_link,
          betpawa_link,
          created_at,
          updated_at,
          image_url,
          packages!inner(name)
        `)
        .in('package_id', packageIds)
        .gte('created_at', earliestSubscription.start_date)
        .order('created_at', { ascending: false });

      if (ticketsError) {
        console.error('❌ Error fetching tickets:', ticketsError);
        setTickets([]);
        setLoading(false);
        return;
      }

      // Get matches for each ticket
      const ticketsWithMatches = await Promise.all(
        (ticketsData || []).map(async (ticket) => {
          const { data: matchesData, error: matchesError } = await supabase
            .from('ticket_matches')
            .select(`
              id,
              match_name,
              match_time,
              prediction,
              odds
            `)
            .eq('ticket_id', ticket.id)
            .order('match_time', { ascending: true });

          if (matchesError) {
            console.error('❌ Error fetching matches for ticket:', ticket.id, matchesError);
            return {
              ...ticket,
              package_name: ticket.packages?.name || 'Unknown Package',
              matches: []
            };
          }

          return {
            ...ticket,
            package_name: ticket.packages?.name || 'Unknown Package',
            matches: matchesData || []
          };
        })
      );

      console.log('🎫 Tickets with matches fetched:', ticketsWithMatches);
      setTickets(ticketsWithMatches);
    } catch (error) {
      console.error('💥 Error fetching tickets:', error);
      setTickets([]);
    }
    setLoading(false);
  };

  const setupRealtimeSubscription = () => {
    if (!user) return;

    console.log('🎫 Setting up realtime subscription for tickets');
    
    const channel = supabase
      .channel(`tickets-realtime-${user.id}-${Math.random().toString(36).slice(2)}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tickets'
        },
        (payload) => {
          console.log('🎫 Ticket realtime event:', payload);
          fetchTickets();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'ticket_matches'
        },
        (payload) => {
          console.log('🎫 Ticket match realtime event:', payload);
          fetchTickets();
        }
      )
      .subscribe();

    return () => {
      console.log('🎫 Cleaning up ticket subscription');
      supabase.removeChannel(channel);
    };
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'won':
        return 'bg-green-100 text-green-800';
      case 'lost':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'won':
        return '🏆';
      case 'lost':
        return '❌';
      case 'pending':
        return '⏳';
      default:
        return '📝';
    }
  };

  return {
    tickets,
    loading,
    getStatusColor,
    getStatusIcon,
    refetch: fetchTickets
  };
}
