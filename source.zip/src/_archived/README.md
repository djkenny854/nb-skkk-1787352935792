# Archived: Pesapal integration

The Pesapal payment integration was replaced by Nylon Pay.

- Edge functions moved to `supabase/functions/_archived/` and removed from `supabase/config.toml` so they are no longer deployed.
- Frontend pages/hooks/components moved here (`src/_archived/pesapal-pages/`) and excluded from the TypeScript build via `tsconfig.app.json`.
- The `pesapal_transactions` table is left in place to preserve historical data.

## To restore

1. Move the files back to their original paths (`supabase/functions/*`, `src/pages/*`, `src/hooks/*`, `src/components/*`).
2. Re-add the `[functions.*]` blocks for the Pesapal functions in `supabase/config.toml`.
3. Re-add the `/payment-success`, `/payment-cancel`, `/pesapal-callback` routes and imports in `src/App.tsx`.
4. Replace the Nylon Pay flow in `src/components/PackagesTab.tsx` with the Pesapal one.
