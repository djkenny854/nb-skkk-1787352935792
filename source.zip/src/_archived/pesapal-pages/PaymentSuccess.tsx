import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Clock, AlertCircle, Sparkles, PartyPopper, Gift } from 'lucide-react';
import { usePaymentStatus } from '@/hooks/usePaymentStatus';
import { Progress } from '@/components/ui/progress';

export default function PaymentSuccess() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { checkPaymentStatus, loading } = usePaymentStatus();
  const [verificationStatus, setVerificationStatus] = useState<'checking' | 'success' | 'failed' | 'pending'>('checking');
  const [countdown, setCountdown] = useState(5);
  const [isRedirecting, setIsRedirecting] = useState(false);
  
  const orderTrackingId = searchParams.get('OrderTrackingId');
  const status = searchParams.get('status');

  useEffect(() => {
    if (status === 'success') {
      setVerificationStatus('success');
    } else if (status === 'verifying') {
      setVerificationStatus('pending');
    } else if (orderTrackingId) {
      verifyPayment();
    } else {
      setVerificationStatus('success');
    }
  }, [orderTrackingId, status]);

  useEffect(() => {
    if (verificationStatus === 'success' && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (verificationStatus === 'success' && countdown === 0 && !isRedirecting) {
      setIsRedirecting(true);
      navigate('/app');
    }
  }, [verificationStatus, countdown, navigate, isRedirecting]);

  const verifyPayment = async () => {
    if (!orderTrackingId) return;
    
    try {
      const isSuccessful = await checkPaymentStatus(orderTrackingId);
      setVerificationStatus(isSuccessful ? 'success' : 'pending');
    } catch (error) {
      console.error('Payment verification error:', error);
      setVerificationStatus('failed');
    }
  };

  const handleRetryVerification = () => {
    setVerificationStatus('checking');
    verifyPayment();
  };

  const getStatusContent = () => {
    switch (verificationStatus) {
      case 'checking':
        return {
          icon: (
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl animate-pulse" />
              <Clock className="h-12 w-12 text-primary animate-spin relative z-10" />
            </div>
          ),
          title: 'Verifying Your Payment',
          description: 'Please wait while we confirm your payment...',
          action: (
            <div className="w-full">
              <Progress value={50} className="w-full animate-pulse" />
            </div>
          )
        };
      
      case 'success':
        return {
          icon: (
            <div className="relative animate-scale-in">
              <div className="absolute inset-0 bg-green-500/30 rounded-full blur-2xl animate-pulse" />
              <div className="relative bg-gradient-to-br from-green-400 to-emerald-600 rounded-full p-4">
                <CheckCircle className="h-12 w-12 text-white" strokeWidth={2.5} />
              </div>
              <PartyPopper className="absolute -top-1 -right-1 h-6 w-6 text-yellow-500 animate-bounce" />
              <Gift className="absolute -bottom-0.5 -left-1 h-5 w-5 text-pink-500 animate-pulse" />
            </div>
          ),
          title: 'Payment Successful!',
          description: 'Congratulations! 🎉 Your subscription has been activated.',
          action: (
            <div className="space-y-3 w-full">
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 text-center">
                <p className="text-xs font-medium text-foreground mb-1">
                  Redirecting to your dashboard...
                </p>
                <div className="flex items-center justify-center gap-2 mb-2">
                  <span className="text-2xl font-bold text-primary">{countdown}</span>
                  <span className="text-xs text-muted-foreground">second{countdown !== 1 ? 's' : ''}</span>
                </div>
                <Progress value={(5 - countdown) * 20} className="w-full h-1.5" />
              </div>
              <Button 
                onClick={() => navigate('/app')} 
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-semibold text-sm" 
                size="default"
              >
                Go to Dashboard Now
              </Button>
            </div>
          )
        };
      
      case 'pending':
        return {
          icon: (
            <div className="relative">
              <div className="absolute inset-0 bg-orange-500/20 rounded-full blur-xl animate-pulse" />
              <div className="relative bg-gradient-to-br from-orange-400 to-amber-600 rounded-full p-4">
                <Clock className="h-12 w-12 text-white" strokeWidth={2.5} />
              </div>
            </div>
          ),
          title: 'Payment Processing',
          description: 'Your payment was received. We\'re processing your subscription.',
          action: (
            <div className="space-y-2 w-full">
              <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-2 text-center">
                <p className="text-xs text-muted-foreground">
                  💡 No need to wait here!
                </p>
              </div>
              <Button 
                onClick={handleRetryVerification} 
                variant="outline" 
                className="w-full border-orange-500/50 hover:bg-orange-500/10 text-sm" 
                disabled={loading}
                size="sm"
              >
                {loading ? 'Checking...' : 'Check Status Again'}
              </Button>
              <Button 
                onClick={() => navigate('/app')} 
                className="w-full bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white text-sm"
                size="sm"
              >
                Go to Dashboard
              </Button>
            </div>
          )
        };
      
      case 'failed':
        return {
          icon: (
            <div className="relative">
              <div className="absolute inset-0 bg-red-500/20 rounded-full blur-xl animate-pulse" />
              <div className="relative bg-gradient-to-br from-red-400 to-rose-600 rounded-full p-4">
                <AlertCircle className="h-12 w-12 text-white" strokeWidth={2.5} />
              </div>
            </div>
          ),
          title: 'Verification Issue',
          description: 'We encountered an issue. If you completed the payment, it will be processed.',
          action: (
            <div className="space-y-2 w-full">
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-2 text-center">
                <p className="text-xs text-muted-foreground">
                  💬 Need help? Contact support
                </p>
              </div>
              <Button 
                onClick={handleRetryVerification} 
                variant="outline" 
                className="w-full border-red-500/50 hover:bg-red-500/10 text-sm" 
                disabled={loading}
                size="sm"
              >
                {loading ? 'Retrying...' : 'Try Again'}
              </Button>
              <Button 
                onClick={() => navigate('/app')} 
                className="w-full text-sm"
                variant="secondary"
                size="sm"
              >
                Back to Dashboard
              </Button>
            </div>
          )
        };
    }
  };

  const statusContent = getStatusContent();

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {verificationStatus === 'success' && (
          <>
            {[...Array(8)].map((_, i) => (
              <Sparkles
                key={i}
                className="absolute text-yellow-400 animate-pulse"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  width: `${Math.random() * 16 + 12}px`,
                  height: `${Math.random() * 16 + 12}px`,
                  animationDelay: `${Math.random() * 2}s`,
                  opacity: Math.random() * 0.5 + 0.3
                }}
              />
            ))}
          </>
        )}
        
        {verificationStatus !== 'success' && (
          <>
            <div className="absolute top-20 left-10 w-48 h-48 bg-primary/5 rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-20 right-10 w-64 h-64 bg-primary/3 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
          </>
        )}
      </div>
      
      {/* Main content card */}
      <Card className="w-full max-w-sm relative z-10 shadow-xl border border-border animate-scale-in backdrop-blur-sm bg-card">
        <CardHeader className="text-center pb-4 pt-6 px-4">
          <div className="flex justify-center mb-4">
            {statusContent.icon}
          </div>
          <CardTitle className="text-xl font-bold text-foreground">
            {statusContent.title}
          </CardTitle>
        </CardHeader>
        
        <CardContent className="text-center space-y-4 px-4 pb-6">
          <p className="text-muted-foreground text-sm leading-relaxed">
            {statusContent.description}
          </p>
          
          {orderTrackingId && (
            <div className="bg-muted/30 p-3 rounded-lg text-xs border border-border">
              <p className="text-muted-foreground mb-0.5 uppercase tracking-wide">Order ID</p>
              <p className="font-mono font-medium text-foreground break-all">{orderTrackingId}</p>
            </div>
          )}
          
          <div className="pt-1">
            {statusContent.action}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
