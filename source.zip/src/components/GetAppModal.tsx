import { useState, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Download, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

interface GetAppModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function GetAppModal({ open, onOpenChange }: GetAppModalProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [appData, setAppData] = useState({
    name: 'Kalaso',
    version: '1.0.0',
    developer: 'SK Sports Analytics',
    size: '2.5 MB',
    icon: '/adobe sk logo.png'
  });

  useEffect(() => {
    if (open) {
      setIsLoading(true);
      // Simulate loading app data
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [open]);

  const handleDownload = () => {
    // Implement actual download logic here
    console.log('Downloading app...');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-black border-gray-800">
        <div className="space-y-6 py-4">
          {isLoading ? (
            <>
              {/* Loading Skeleton */}
              <div className="flex flex-col items-center space-y-4">
                <Skeleton className="h-24 w-24 rounded-2xl bg-gray-800" />
                <div className="space-y-2 w-full">
                  <Skeleton className="h-6 w-3/4 mx-auto bg-gray-800 animate-pulse" />
                  <Skeleton className="h-4 w-1/2 mx-auto bg-gray-800 animate-pulse" />
                </div>
                <div className="w-full space-y-3 pt-4">
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-4 w-20 bg-gray-800 animate-pulse" />
                    <Skeleton className="h-4 w-32 bg-gray-800 animate-pulse" />
                  </div>
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-4 w-20 bg-gray-800 animate-pulse" />
                    <Skeleton className="h-4 w-24 bg-gray-800 animate-pulse" />
                  </div>
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-4 w-20 bg-gray-800 animate-pulse" />
                    <Skeleton className="h-4 w-16 bg-gray-800 animate-pulse" />
                  </div>
                </div>
                <Skeleton className="h-12 w-full rounded-xl bg-gray-800 animate-pulse" />
              </div>
            </>
          ) : (
            <>
              {/* App Icon */}
              <div className="flex justify-center">
                <div className="relative">
                  <div className="absolute inset-0 bg-primary/20 rounded-2xl blur-xl animate-pulse" />
                  <img 
                    src={appData.icon} 
                    alt={appData.name}
                    className="relative h-24 w-24 rounded-2xl shadow-lg object-cover"
                  />
                </div>
              </div>

              {/* App Info */}
              <div className="text-center space-y-2">
                <h2 className="text-2xl font-bold text-white">{appData.name}</h2>
                <p className="text-sm text-gray-400">Version {appData.version}</p>
              </div>

              {/* Details */}
              <div className="space-y-3 bg-gray-900 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-400">Developer</span>
                  <span className="text-sm font-medium text-white">{appData.developer}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-400">Size</span>
                  <span className="text-sm font-medium text-white">{appData.size}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-400">Platform</span>
                  <span className="text-sm font-medium text-white">Android / iOS</span>
                </div>
              </div>

              {/* Download Button */}
              <Button 
                onClick={handleDownload}
                className="w-full bg-gradient-to-r from-primary to-orange-600 hover:from-primary/90 hover:to-orange-600/90 text-white h-12"
                size="lg"
              >
                <Download className="mr-2 h-5 w-5 animate-bounce" />
                Download App
              </Button>

              <p className="text-xs text-center text-gray-500">
                Compatible with Android 8.0+ and iOS 12.0+
              </p>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
