
import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface HorizontalScrollProps {
  children: ReactNode;
  className?: string;
  itemClassName?: string;
}

export function HorizontalScroll({ children, className, itemClassName }: HorizontalScrollProps) {
  return (
    <div className={cn("overflow-x-auto scrollbar-hide", className)}>
      <div className={cn("flex space-x-4 pb-2", itemClassName)}>
        {children}
      </div>
    </div>
  );
}
