import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle2, ShieldCheck, XCircle } from "lucide-react";
import type { NylonPaymentStatus } from "@/hooks/useNylonPayment";
import { LoadingSpinner } from "./LoadingSpinner";
import { motion } from "framer-motion";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  status: NylonPaymentStatus;
  phoneNumber: string;
  amount: number;
  errorMsg?: string | null;
  onRetry?: () => void;
  onDone?: () => void;
}

const formatUGX = (n: number) =>
  new Intl.NumberFormat("en-UG", { style: "currency", currency: "UGX", minimumFractionDigits: 0 }).format(n);

export function NylonPaymentModal({ open, onOpenChange, status, phoneNumber, amount, errorMsg, onRetry, onDone }: Props) {
  return (
    <Dialog open={open} onOpenChange={(v) => { if (status !== "pending") onOpenChange(v); }}>
      <DialogContent className="max-w-sm rounded-3xl border-border bg-background p-6 text-center">
        {status === "pending" && (
          <div className="space-y-5">
            <LoadingSpinner size="xl" variant="google" />
            <div>
              <h3 className="text-xl font-bold">Approve payment</h3>
              <p className="text-sm text-muted-foreground mt-2">
                We sent a payment prompt to <span className="font-medium text-foreground">{phoneNumber}</span>.
                Approve it to pay <span className="font-medium text-foreground">{formatUGX(amount)}</span>.
              </p>
            </div>
            <div className="rounded-2xl bg-muted/50 px-4 py-3 text-left">
              <div className="flex items-start gap-3">
                <ShieldCheck className="mt-0.5 h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm font-semibold text-foreground">Secure mobile money checkout</p>
                  <p className="text-xs text-muted-foreground">Keep this screen open while Nylon Pay confirms your transaction.</p>
                </div>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Waiting for confirmation…</p>
          </div>
        )}

        {status === "completed" && (
          <div className="space-y-5">
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 420, damping: 18 }}
              className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-green-500/15"
            >
              <CheckCircle2 className="h-12 w-12 text-green-500" />
            </motion.div>
            <div>
              <h3 className="text-xl font-bold">You're premium</h3>
              <p className="mt-2 text-sm text-muted-foreground">Payment confirmed. Your package access is now active.</p>
            </div>
            <Button className="h-12 w-full rounded-full font-bold" onClick={onDone}>Continue</Button>
          </div>
        )}

        {status === "failed" && (
          <div className="space-y-4">
            <div className="mx-auto w-16 h-16 rounded-full bg-destructive/15 flex items-center justify-center">
              <XCircle className="w-9 h-9 text-destructive" />
            </div>
            <h3 className="text-lg font-bold">Payment Failed</h3>
            <p className="text-sm text-muted-foreground">{errorMsg || "The payment was not completed."}</p>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1 rounded-full" onClick={() => onOpenChange(false)}>Close</Button>
              {onRetry && <Button className="flex-1 rounded-full" onClick={onRetry}>Try Again</Button>}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
