import { ReactNode, useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { HomeTab } from './HomeTab';
import { EnhancedTipsTab } from './EnhancedTipsTab';
import { PackagesTab } from './PackagesTab';
import ProfileTab from './ProfileTab';
import { ResponsiveLayout } from './ResponsiveLayout';
import { useLoginNotifications } from '@/hooks/useLoginNotifications';
import { useDeviceTracking } from '@/hooks/useDeviceTracking';

interface LayoutProps {
  children?: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [activeTab, setActiveTab] = useState("home");
  
  // Initialize login notifications and device tracking
  useLoginNotifications();
  useDeviceTracking();

  if (children) {
    return (
      <ResponsiveLayout>
        {children}
      </ResponsiveLayout>
    );
  }

  return (
    <ResponsiveLayout 
      showBottomNav={true} 
      activeTab={activeTab} 
      onTabChange={setActiveTab}
    >
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="p-4 md:p-6">
            <TabsContent value="home" className="mt-0">
              <HomeTab />
            </TabsContent>
            <TabsContent value="tips" className="mt-0">
              <EnhancedTipsTab />
            </TabsContent>
            <TabsContent value="packages" className="mt-0">
              <PackagesTab />
            </TabsContent>
            <TabsContent value="profile" className="mt-0">
              <ProfileTab />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </ResponsiveLayout>
  );
}
