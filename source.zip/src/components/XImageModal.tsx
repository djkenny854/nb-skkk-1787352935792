import { motion, AnimatePresence } from 'framer-motion';
import { X, Download, Heart, Repeat2, MessageCircle, Share, Bookmark, MoreHorizontal } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

interface XImageModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string;
  ticketName: string;
}

export function XImageModal({ isOpen, onClose, imageUrl, ticketName }: XImageModalProps) {
  const [liked, setLiked] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `${ticketName}-ticket.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 flex"
          onClick={handleBackdropClick}
        >
          {/* Dark overlay */}
          <div className="absolute inset-0 bg-black/90" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 left-4 z-50 p-2 rounded-full bg-background/80 hover:bg-background transition-colors"
          >
            <X className="w-5 h-5 text-foreground" />
          </button>

          {/* More options button */}
          <button
            className="absolute top-4 right-4 z-50 p-2 rounded-full bg-background/80 hover:bg-background transition-colors"
          >
            <MoreHorizontal className="w-5 h-5 text-foreground" />
          </button>

          {/* Main content area */}
          <div className="relative flex w-full h-full">
            {/* Image section */}
            <div className="flex-1 flex items-center justify-center p-4">
              <motion.img
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                transition={{ duration: 0.2 }}
                src={imageUrl}
                alt={ticketName}
                className="max-w-full max-h-full object-contain rounded-lg"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = '/placeholder.svg';
                }}
              />
            </div>

            {/* Right sidebar with post details (visible on larger screens) */}
            <motion.div
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 100, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="hidden lg:flex flex-col w-[350px] bg-background border-l border-border h-full overflow-y-auto"
            >
              {/* Header */}
              <div className="p-4 border-b border-border">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center text-white font-bold">
                    {ticketName.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-1">
                      <span className="font-bold text-foreground">{ticketName}</span>
                      <svg viewBox="0 0 22 22" className="w-4 h-4 text-primary fill-current">
                        <path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.69.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.878.633.132 1.29.084 1.897-.136.274.586.705 1.084 1.246 1.439.54.354 1.17.551 1.816.569.647-.016 1.276-.213 1.817-.567s.972-.854 1.245-1.44c.604.239 1.266.296 1.903.164.636-.132 1.22-.447 1.68-.907.46-.46.776-1.044.908-1.681s.075-1.299-.165-1.903c.586-.274 1.084-.705 1.439-1.246.354-.54.551-1.17.569-1.816zM9.662 14.85l-3.429-3.428 1.293-1.302 2.072 2.072 4.4-4.794 1.347 1.246z" />
                      </svg>
                    </div>
                    <span className="text-muted-foreground text-sm">@{ticketName.toLowerCase().replace(/\s/g, '')}</span>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 p-4">
                <p className="text-foreground text-[15px] mb-4">
                  Premium betting ticket with carefully selected matches. 🎯⚽
                </p>
                <div className="text-muted-foreground text-sm">
                  {new Date().toLocaleDateString('en-US', { 
                    hour: 'numeric', 
                    minute: '2-digit',
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric'
                  })}
                </div>
              </div>

              {/* Stats */}
              <div className="px-4 py-3 border-t border-border">
                <div className="flex gap-4 text-sm">
                  <span><strong className="text-foreground">142</strong> <span className="text-muted-foreground">Reposts</span></span>
                  <span><strong className="text-foreground">1,847</strong> <span className="text-muted-foreground">Likes</span></span>
                  <span><strong className="text-foreground">89</strong> <span className="text-muted-foreground">Bookmarks</span></span>
                </div>
              </div>

              {/* Actions */}
              <div className="px-2 py-2 border-t border-border flex items-center justify-around">
                <button className="p-2 hover:bg-primary/10 rounded-full group transition-colors">
                  <MessageCircle className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
                </button>
                <button className="p-2 hover:bg-green-500/10 rounded-full group transition-colors">
                  <Repeat2 className="w-5 h-5 text-muted-foreground group-hover:text-green-500" />
                </button>
                <button 
                  onClick={() => setLiked(!liked)}
                  className="p-2 hover:bg-pink-500/10 rounded-full group transition-colors"
                >
                  <Heart className={cn(
                    "w-5 h-5 transition-colors",
                    liked ? "fill-pink-500 text-pink-500" : "text-muted-foreground group-hover:text-pink-500"
                  )} />
                </button>
                <button 
                  onClick={() => setBookmarked(!bookmarked)}
                  className="p-2 hover:bg-primary/10 rounded-full group transition-colors"
                >
                  <Bookmark className={cn(
                    "w-5 h-5 transition-colors",
                    bookmarked ? "fill-primary text-primary" : "text-muted-foreground group-hover:text-primary"
                  )} />
                </button>
                <button 
                  onClick={handleDownload}
                  className="p-2 hover:bg-primary/10 rounded-full group transition-colors"
                >
                  <Download className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
                </button>
                <button className="p-2 hover:bg-primary/10 rounded-full group transition-colors">
                  <Share className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
                </button>
              </div>
            </motion.div>
          </div>

          {/* Mobile bottom actions bar */}
          <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur border-t border-border px-4 py-3">
            <div className="flex items-center justify-around">
              <button className="p-2 hover:bg-primary/10 rounded-full group transition-colors">
                <MessageCircle className="w-6 h-6 text-muted-foreground group-hover:text-primary" />
              </button>
              <button className="p-2 hover:bg-green-500/10 rounded-full group transition-colors">
                <Repeat2 className="w-6 h-6 text-muted-foreground group-hover:text-green-500" />
              </button>
              <button 
                onClick={() => setLiked(!liked)}
                className="p-2 hover:bg-pink-500/10 rounded-full group transition-colors"
              >
                <Heart className={cn(
                  "w-6 h-6 transition-colors",
                  liked ? "fill-pink-500 text-pink-500" : "text-muted-foreground group-hover:text-pink-500"
                )} />
              </button>
              <button 
                onClick={() => setBookmarked(!bookmarked)}
                className="p-2 hover:bg-primary/10 rounded-full group transition-colors"
              >
                <Bookmark className={cn(
                  "w-6 h-6 transition-colors",
                  bookmarked ? "fill-primary text-primary" : "text-muted-foreground group-hover:text-primary"
                )} />
              </button>
              <button 
                onClick={handleDownload}
                className="p-2 hover:bg-primary/10 rounded-full group transition-colors"
              >
                <Download className="w-6 h-6 text-muted-foreground group-hover:text-primary" />
              </button>
              <button className="p-2 hover:bg-primary/10 rounded-full group transition-colors">
                <Share className="w-6 h-6 text-muted-foreground group-hover:text-primary" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
