import { Home, User, Shield, KeyRound, Link2, Database, Users, UsersRound, CreditCard, Download, Bell } from "lucide-react"
import { NavLink, useLocation } from "react-router-dom"
import {
  Sidebar,
  SidebarContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar"
import { useIsMobile } from "@/hooks/use-mobile"
import kalasoLogo from '@/assets/kalaso-logo.png'

const navigation = [
  { 
    title: "Home", 
    url: "/app", 
    icon: Home,
    bgColor: "bg-blue-100",
    iconColor: "text-blue-600"
  },
  { 
    title: "Premium Tips", 
    url: "/app/tips", 
    icon: Shield,
    bgColor: "bg-cyan-100",
    iconColor: "text-cyan-600"
  },
  { 
    title: "Free Tips", 
    url: "/app/free-tips", 
    icon: KeyRound,
    bgColor: "bg-yellow-100",
    iconColor: "text-yellow-600"
  },
  { 
    title: "Packages", 
    url: "/app/packages", 
    icon: Link2,
    bgColor: "bg-green-100",
    iconColor: "text-green-600"
  },
  { 
    title: "Transactions", 
    url: "/app/transactions", 
    icon: Database,
    bgColor: "bg-purple-100",
    iconColor: "text-purple-600"
  },
  { 
    title: "Profile", 
    url: "/app/profile", 
    icon: User,
    bgColor: "bg-pink-100",
    iconColor: "text-pink-600"
  },
]

export function AppSidebar() {
  const { state, setOpenMobile } = useSidebar()
  const location = useLocation()
  const currentPath = location.pathname
  const collapsed = state === "collapsed"
  const isMobile = useIsMobile()

  const isActive = (path: string) => {
    if (path === "/app") {
      return currentPath === "/app"
    }
    return currentPath.startsWith(path)
  }

  const handleNavClick = () => {
    if (isMobile) {
      setOpenMobile(false)
    }
  }

  return (
    <Sidebar className="border-r-0 bg-background" collapsible="icon">
      {/* Logo Header */}
      <div className="p-4 pb-3">
        <div className="flex items-center gap-3">
          <img 
            src={kalasoLogo} 
            alt="Kalaso Football Predictions" 
            className="h-10 w-auto max-w-[160px] object-contain rounded-md"
          />
          {!collapsed && (
            <span className="text-[18px] font-semibold text-foreground tracking-tight">Kalaso Football Predictions</span>
          )}
        </div>
      </div>
      
      <SidebarContent className="px-3">
        <SidebarMenu className="space-y-1">
          {navigation.map((item) => (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton asChild className="h-12 px-3">
                <NavLink 
                  to={item.url} 
                  className={`flex items-center gap-4 rounded-full transition-all duration-200 ${
                    isActive(item.url) 
                      ? "bg-blue-50 text-blue-700 font-medium" 
                      : "text-foreground hover:bg-muted"
                  }`}
                  onClick={handleNavClick}
                >
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full ${item.bgColor}`}>
                    <item.icon className={`h-[18px] w-[18px] ${item.iconColor}`} />
                  </div>
                  {!collapsed && (
                    <span className="text-[14px]">{item.title}</span>
                  )}
                </NavLink>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>

      <SidebarFooter className="border-t-0 p-4 mt-auto">
        <div className="flex items-center gap-6 text-[13px] text-muted-foreground px-3">
          <a href="/terms" className="hover:text-foreground transition-colors">Privacy</a>
          <a href="/terms" className="hover:text-foreground transition-colors">Terms</a>
          <a href="/help" className="hover:text-foreground transition-colors">Help</a>
          <a href="/contact" className="hover:text-foreground transition-colors">About</a>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
