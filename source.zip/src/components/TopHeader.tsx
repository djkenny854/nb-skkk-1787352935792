import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Search, Settings, HelpCircle, X, Package, FileText, Download } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/hooks/useAuth';
import { NotificationDropdown } from './NotificationDropdown';
import { useTipSearch } from '@/hooks/useTipSearch';
import { usePWAInstall } from '@/hooks/usePWAInstall';
import kalasoLogo from '@/assets/kalaso-logo.png';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export function TopHeader() {
  const { user } = useAuth();
  const { canInstall, promptInstall } = usePWAInstall();
  const navigate = useNavigate();
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { results, isSearching, search, clearResults } = useTipSearch();
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchQuery) {
        search(searchQuery);
      } else {
        clearResults();
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery, search, clearResults]);

  // Close search on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setSearchOpen(false);
        setSearchQuery('');
        clearResults();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [clearResults]);

  const handleResultClick = (result: typeof results[0]) => {
    if (result.type === 'package') {
      navigate('/app/packages');
    } else {
      navigate('/app/tips');
    }
    setSearchOpen(false);
    setSearchQuery('');
    clearResults();
  };

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'won': return 'text-green-500';
      case 'lost': return 'text-red-500';
      default: return 'text-yellow-500';
    }
  };

  return (
    <header className="sticky top-0 z-20 bg-background/95 backdrop-blur-md border-b border-border">
      <div className="flex items-center justify-between px-4 h-14">
        {/* Logo */}
        <div 
          className="flex items-center gap-2 cursor-pointer"
          onClick={() => navigate('/app')}
        >
          <img 
            src={kalasoLogo} 
            alt="Kalaso logo" 
            className="h-8 w-auto max-w-[150px] object-contain rounded-md"
          />
                  </div>

        {/* Right Icons */}
        <div className="flex items-center gap-1">
          {/* Install app (web only, hidden once installed / in native app) */}
          {canInstall && (
            <button
              onClick={promptInstall}
              className="flex items-center gap-1.5 h-8 px-3 mr-1 rounded-full bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
              aria-label="Install app"
            >
              <Download className="w-4 h-4" />
              <span className="hidden xs:inline sm:inline">Install app</span>
            </button>
          )}

          {/* Search */}
          <button 
            onClick={() => {
              setSearchOpen(!searchOpen);
              if (!searchOpen) {
                setTimeout(() => inputRef.current?.focus(), 100);
              }
            }}
            className="p-2 hover:bg-muted/80 rounded-full transition-colors"
          >
            <Search className="w-5 h-5 text-foreground" />
          </button>

          {/* Notifications */}
          <NotificationDropdown />

          {/* Help */}
          <button 
            onClick={() => navigate('/help')}
            className="p-2 hover:bg-muted/80 rounded-full transition-colors"
          >
            <HelpCircle className="w-5 h-5 text-foreground" />
          </button>

          {/* Settings */}
          <button 
            onClick={() => navigate('/app/profile')}
            className="p-2 hover:bg-muted/80 rounded-full transition-colors"
          >
            <Settings className="w-5 h-5 text-foreground" />
          </button>

          {/* User Avatar */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="p-1 hover:bg-muted/80 rounded-full transition-colors">
                <Avatar className="w-7 h-7">
                  <AvatarImage src={user?.user_metadata?.avatar_url} />
                  <AvatarFallback className="bg-primary/20 text-primary text-xs font-medium">
                    {user?.email?.[0]?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => navigate('/app/profile')} className="gap-2">
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/help')} className="gap-2">
                <HelpCircle className="w-4 h-4" />
                <span>Help Center</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Search Bar - Expandable */}
      {searchOpen && (
        <div ref={searchRef} className="px-4 pb-3 animate-fade-in">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              ref={inputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search tips, packages..."
              className="w-full h-10 pl-10 pr-10 bg-muted border border-border rounded-full text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  clearResults();
                }}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-muted rounded-full"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            )}
          </div>

          {/* Search Results */}
          {(results.length > 0 || isSearching) && (
            <div className="mt-2 bg-background border border-border rounded-xl shadow-lg overflow-hidden max-h-80 overflow-y-auto">
              {isSearching ? (
                <div className="p-4 text-center text-sm text-muted-foreground">
                  Searching...
                </div>
              ) : (
                results.map((result) => (
                  <button
                    key={`${result.type}-${result.id}`}
                    onClick={() => handleResultClick(result)}
                    className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors text-left"
                  >
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      {result.type === 'package' ? (
                        <Package className="w-4 h-4 text-primary" />
                      ) : (
                        <FileText className="w-4 h-4 text-primary" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">
                        {result.title}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {result.subtitle}
                        {result.status && (
                          <span className={`ml-2 ${getStatusColor(result.status)}`}>
                            • {result.status}
                          </span>
                        )}
                      </p>
                    </div>
                  </button>
                ))
              )}
              {!isSearching && results.length === 0 && searchQuery.length >= 2 && (
                <div className="p-4 text-center text-sm text-muted-foreground">
                  No results found
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </header>
  );
}
