import { ReactNode, useState } from 'react'
import { useLocation, NavLink, useNavigate } from 'react-router-dom'
import { 
  Home, 
  Bell, 
  User, 
  Settings, 
  MoreHorizontal,
  Shield,
  Gift,
  CreditCard,
  Target,
  Download,
  LogOut,
  HelpCircle,
  FileText
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'
import { useIsMobile } from '@/hooks/use-mobile'
import { useCapacitorDetection } from '@/hooks/useCapacitorDetection'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { supabase } from '@/integrations/supabase/client'
import { XRightSidebar } from './XRightSidebar'
import { XBottomNav } from './XBottomNav'
import { NotificationDropdown } from './NotificationDropdown'
import { GetAppModal } from './GetAppModal'
import kalasoLogo from '@/assets/kalaso-logo.png'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface XStyleLayoutProps {
  children: ReactNode
}

const navItems = [
  { icon: Home, label: 'Home', path: '/app' },
  { icon: Target, label: 'Premium Tips', path: '/app/tips' },
  { icon: Gift, label: 'Free Tips', path: '/app/free-tips' },
  { icon: Shield, label: 'Packages', path: '/app/packages' },
  { icon: CreditCard, label: 'Transactions', path: '/app/transactions' },
  { icon: Bell, label: 'Notifications', path: '/app/notifications', isNotification: true },
  { icon: User, label: 'Profile', path: '/app/profile' },
]

export function XStyleLayout({ children }: XStyleLayoutProps) {
  const { user } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const isMobile = useIsMobile()
  const { isNative } = useCapacitorDetection()
  const [getAppModalOpen, setGetAppModalOpen] = useState(false)
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false)

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    navigate('/auth')
  }

  const isActive = (path: string) => {
    if (path === '/app') {
      return location.pathname === '/app'
    }
    return location.pathname.startsWith(path)
  }

  const hideRightSidebar = location.pathname.startsWith('/app/packages')

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex justify-center w-full">
        <div className="flex w-full max-w-[1400px]">
          {/* Left Sidebar - Hidden on mobile and tablet */}
          <aside className="sticky top-0 h-screen w-[275px] flex-shrink-0 overflow-y-auto border-r border-border px-3 py-2 hidden lg:flex flex-col">
            <div className="flex flex-col h-full">
              {/* Logo */}
              <div className="px-3 py-3">
                <NavLink to="/app" className="flex items-center gap-3">
                  <img 
                    src={kalasoLogo} 
                    alt="Kalaso logo" 
                    className="h-10 w-auto max-w-[170px] object-contain rounded-md"
                  />
                                  </NavLink>
              </div>

              {/* Navigation */}
              <nav className="flex-1 mt-1">
                {navItems.map((item) => (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    className={cn(
                      "flex items-center gap-5 px-3 py-3 rounded-full transition-colors hover:bg-muted/80 my-0.5 group",
                      isActive(item.path) && "font-bold"
                    )}
                  >
                    {item.isNotification ? (
                      <div className="relative">
                        <item.icon className={cn(
                          "w-[26px] h-[26px] transition-colors",
                          isActive(item.path) ? "text-foreground" : "text-foreground"
                        )} strokeWidth={isActive(item.path) ? 2.5 : 1.75} />
                      </div>
                    ) : (
                      <item.icon className={cn(
                        "w-[26px] h-[26px] transition-colors",
                        isActive(item.path) ? "text-foreground" : "text-foreground"
                      )} strokeWidth={isActive(item.path) ? 2.5 : 1.75} />
                    )}
                    <span className={cn(
                      "text-[20px] tracking-tight",
                      isActive(item.path) ? "font-bold" : "font-normal"
                    )}>
                      {item.label}
                    </span>
                  </NavLink>
                ))}

                {/* More dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-5 px-3 py-3 rounded-full transition-colors hover:bg-muted/80 my-0.5 w-full text-left">
                      <MoreHorizontal className="w-[26px] h-[26px] text-foreground" strokeWidth={1.75} />
                      <span className="text-[20px] tracking-tight font-normal">More</span>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-[240px]">
                    {/* Hide Download App option when running in native Capacitor environment */}
                    {!isNative && (
                      <DropdownMenuItem onClick={() => setGetAppModalOpen(true)} className="gap-3 py-3">
                        <Download className="w-5 h-5" />
                        <span>Download App</span>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={() => navigate('/help')} className="gap-3 py-3">
                      <Settings className="w-5 h-5" />
                      <span>Settings & Support</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </nav>

              {/* Subscribe Button */}
              <Button 
                onClick={() => navigate('/app/packages')}
                className="w-full mt-4 h-[52px] rounded-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-[17px]"
              >
                Subscribe
              </Button>

              {/* User Profile */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-3 p-3 mt-3 mb-3 rounded-full hover:bg-muted/80 transition-colors w-full">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={user?.user_metadata?.avatar_url} />
                      <AvatarFallback className="bg-muted text-foreground text-sm font-medium">
                        {user?.email?.[0]?.toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 text-left overflow-hidden">
                      <div className="font-bold text-[15px] truncate">
                        {user?.user_metadata?.full_name || 'User'}
                      </div>
                      <div className="text-muted-foreground text-[15px] truncate">
                        @{user?.email?.split('@')[0] || 'user'}
                      </div>
                    </div>
                    <MoreHorizontal className="w-5 h-5 text-foreground" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[280px]">
                  <DropdownMenuItem onClick={() => navigate('/app/profile')} className="gap-3 py-3">
                    <User className="w-5 h-5" />
                    <span>Profile Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="gap-3 py-3 text-destructive">
                    <LogOut className="w-5 h-5" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </aside>

          {/* Main Content - Increased width */}
          <main className={cn(
            "flex-1 min-h-screen border-r border-border",
            isMobile ? "max-w-full pb-16" : hideRightSidebar ? "max-w-[1050px]" : "max-w-[700px]"
          )}>
            <div className="h-screen overflow-y-auto">
              <header className="sticky top-0 z-40 flex h-14 items-center justify-between border-b border-border bg-background/95 px-4 backdrop-blur lg:hidden">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 rounded-full p-0"
                  onClick={() => setMobileSidebarOpen(true)}
                  aria-label="Open profile menu"
                >
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={user?.user_metadata?.avatar_url} />
                    <AvatarFallback className="bg-muted text-foreground text-sm font-bold">
                      {user?.email?.[0]?.toUpperCase() || 'U'}
                    </AvatarFallback>
                  </Avatar>
                </Button>
                <NavLink to="/app" className="absolute left-1/2 -translate-x-1/2">
                  <img src={kalasoLogo} alt="Kalaso" className="h-9 w-auto max-w-[150px] object-contain rounded-md" />
                </NavLink>
                <Button
                  onClick={() => navigate('/app/packages')}
                  className="h-9 rounded-full px-4 text-sm font-bold"
                >
                  Subscribe
                </Button>
              </header>
              {children}
            </div>
          </main>

          {/* Right Sidebar - Hidden on mobile, tablet and the packages page */}
          {!hideRightSidebar && (
            <aside className="sticky top-0 h-screen w-[350px] flex-shrink-0 overflow-y-auto px-6 py-3 hidden xl:block">
              <XRightSidebar />
            </aside>
          )}
        </div>
      </div>

      {/* Mobile/Tablet Bottom Navigation - shown when sidebar is hidden */}
      <div className="lg:hidden">
        <XBottomNav />
      </div>

      <Sheet open={mobileSidebarOpen} onOpenChange={setMobileSidebarOpen}>
        <SheetContent side="left" className="w-[84vw] max-w-[360px] overflow-y-auto p-0">
          <SheetHeader className="sr-only">
            <SheetTitle>Profile menu</SheetTitle>
          </SheetHeader>
          <div className="px-5 pb-6 pt-5">
            <div className="mb-6 flex items-start justify-between">
              <button
                onClick={() => {
                  setMobileSidebarOpen(false)
                  navigate('/app/profile')
                }}
                className="text-left"
              >
                <Avatar className="h-14 w-14">
                  <AvatarImage src={user?.user_metadata?.avatar_url} />
                  <AvatarFallback className="bg-muted text-foreground text-lg font-bold">
                    {user?.email?.[0]?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="mt-3 max-w-[240px]">
                  <p className="truncate text-xl font-bold text-foreground">{user?.user_metadata?.full_name || 'SK Member'}</p>
                  <p className="truncate text-sm text-muted-foreground">@{user?.email?.split('@')[0] || 'member'}</p>
                </div>
              </button>
            </div>

            <nav className="space-y-1">
              {[
                { icon: User, label: 'Profile', path: '/app/profile' },
                { icon: Target, label: 'Premium Tips', path: '/app/tips' },
                { icon: Gift, label: 'Free Tips', path: '/app/free-tips' },
                { icon: Shield, label: 'Packages', path: '/app/packages' },
                { icon: CreditCard, label: 'Transactions', path: '/app/transactions' },
                { icon: Bell, label: 'Notifications', path: '/app/notifications' },
                { icon: HelpCircle, label: 'Help Center', path: '/help' },
                { icon: FileText, label: 'Terms', path: '/terms' },
              ].map((item) => (
                <button
                  key={item.path}
                  onClick={() => {
                    setMobileSidebarOpen(false)
                    navigate(item.path)
                  }}
                  className="flex w-full items-center gap-5 rounded-full px-1 py-3 text-left text-foreground hover:bg-muted/70"
                >
                  <item.icon className="h-7 w-7" strokeWidth={1.9} />
                  <span className="text-xl font-bold">{item.label}</span>
                </button>
              ))}
            </nav>

            {!isNative && (
              <Button
                variant="ghost"
                onClick={() => {
                  setMobileSidebarOpen(false)
                  setGetAppModalOpen(true)
                }}
                className="mt-4 h-12 w-full justify-start gap-5 rounded-full px-1 text-xl font-bold"
              >
                <Download className="h-7 w-7" />
                Download App
              </Button>
            )}

            <div className="mt-5 border-t border-border pt-4">
              <Button
                variant="ghost"
                onClick={handleSignOut}
                className="h-12 w-full justify-start gap-5 rounded-full px-1 text-xl font-bold text-destructive hover:text-destructive"
              >
                <LogOut className="h-7 w-7" />
                Log out
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Get App Modal */}
      <GetAppModal 
        open={getAppModalOpen}
        onOpenChange={setGetAppModalOpen}
      />
    </div>
  )
}
