
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface PasswordResetRequest {
  email: string;
  resetUrl: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, resetUrl }: PasswordResetRequest = await req.json();

    const emailResponse = await resend.emails.send({
      from: "SK Sure Wins <noreply@skusers.vercel.app>",
      to: [email],
      subject: "🔐 Reset Your Password - SK Sure Wins",
      html: `
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Reset Your Password - SK Sure Wins</title>
          <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;600;700&display=swap" rel="stylesheet">
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;600;700&display=swap');
            
            * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
            }
            
            body {
              font-family: 'Raleway', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
              line-height: 1.6;
              color: #1f2937;
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              margin: 0;
              padding: 20px;
              min-height: 100vh;
            }
            
            .email-container {
              max-width: 600px;
              margin: 0 auto;
              background: #ffffff;
              border-radius: 20px;
              overflow: hidden;
              box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
              animation: slideInUp 0.6s ease-out;
            }
            
            @keyframes slideInUp {
              from {
                opacity: 0;
                transform: translateY(30px);
              }
              to {
                opacity: 1;
                transform: translateY(0);
              }
            }
            
            @keyframes pulse {
              0% { transform: scale(1); }
              50% { transform: scale(1.05); }
              100% { transform: scale(1); }
            }
            
            @keyframes shimmer {
              0% { background-position: -200px 0; }
              100% { background-position: 200px 0; }
            }
            
            .header {
              background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
              padding: 40px 20px;
              text-align: center;
              position: relative;
              overflow: hidden;
            }
            
            .header::before {
              content: '';
              position: absolute;
              top: 0;
              left: -100%;
              width: 100%;
              height: 100%;
              background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
              animation: shimmer 2s infinite;
            }
            
            .logo {
              width: 80px;
              height: 80px;
              margin: 0 auto 20px;
              background: white;
              border-radius: 20px;
              display: flex;
              align-items: center;
              justify-content: center;
              box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
              animation: pulse 2s infinite;
            }
            
            .logo img {
              width: 60px;
              height: 60px;
              object-fit: contain;
            }
            
            .header h1 {
              color: white;
              font-size: 28px;
              font-weight: 700;
              margin-bottom: 8px;
              text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            
            .header p {
              color: rgba(255, 255, 255, 0.9);
              font-size: 16px;
              font-weight: 300;
            }
            
            .content {
              padding: 50px 40px;
              text-align: center;
            }
            
            .greeting {
              font-size: 24px;
              font-weight: 600;
              color: #1f2937;
              margin-bottom: 20px;
            }
            
            .message {
              font-size: 16px;
              color: #4b5563;
              margin-bottom: 30px;
              line-height: 1.7;
            }
            
            .reset-button {
              display: inline-block;
              background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
              color: white;
              padding: 16px 40px;
              text-decoration: none;
              border-radius: 50px;
              font-weight: 600;
              font-size: 16px;
              box-shadow: 0 10px 20px rgba(37, 99, 235, 0.3);
              transition: all 0.3s ease;
              margin: 20px 0;
              position: relative;
              overflow: hidden;
            }
            
            .reset-button:hover {
              transform: translateY(-2px);
              box-shadow: 0 15px 30px rgba(37, 99, 235, 0.4);
            }
            
            .reset-button::before {
              content: '';
              position: absolute;
              top: 0;
              left: -100%;
              width: 100%;
              height: 100%;
              background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
              transition: left 0.5s;
            }
            
            .reset-button:hover::before {
              left: 100%;
            }
            
            .security-notice {
              background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
              border: 1px solid #f59e0b;
              border-radius: 16px;
              padding: 20px;
              margin: 30px 0;
              position: relative;
            }
            
            .security-notice::before {
              content: '🔒';
              position: absolute;
              top: -10px;
              left: 20px;
              background: #fbbf24;
              width: 30px;
              height: 30px;
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 16px;
            }
            
            .security-text {
              color: #92400e;
              font-size: 14px;
              font-weight: 500;
              margin-top: 5px;
            }
            
            .url-container {
              background: #f8fafc;
              border: 2px dashed #cbd5e1;
              border-radius: 12px;
              padding: 20px;
              margin: 25px 0;
              word-break: break-all;
            }
            
            .url-text {
              font-family: 'Courier New', monospace;
              font-size: 14px;
              color: #475569;
              line-height: 1.5;
            }
            
            .footer {
              background: #f8fafc;
              padding: 40px 20px;
              text-align: center;
              border-top: 1px solid #e2e8f0;
            }
            
            .footer-content {
              max-width: 400px;
              margin: 0 auto;
            }
            
            .brand-name {
              font-size: 18px;
              font-weight: 700;
              color: #2563eb;
              margin-bottom: 10px;
            }
            
            .footer-text {
              color: #6b7280;
              font-size: 14px;
              margin-bottom: 20px;
            }
            
            .social-links {
              display: flex;
              justify-content: center;
              gap: 15px;
              margin-bottom: 20px;
            }
            
            .social-link {
              width: 40px;
              height: 40px;
              background: #e2e8f0;
              border-radius: 50%;
              display: inline-flex;
              align-items: center;
              justify-content: center;
              color: #64748b;
              text-decoration: none;
              transition: all 0.3s ease;
            }
            
            .social-link:hover {
              background: #2563eb;
              color: white;
              transform: translateY(-2px);
            }
            
            .divider {
              width: 60px;
              height: 4px;
              background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
              border-radius: 2px;
              margin: 30px auto;
            }
            
            @media only screen and (max-width: 600px) {
              .email-container {
                margin: 10px;
                border-radius: 16px;
              }
              
              .content {
                padding: 30px 20px;
              }
              
              .header {
                padding: 30px 20px;
              }
              
              .header h1 {
                font-size: 24px;
              }
              
              .greeting {
                font-size: 20px;
              }
              
              .reset-button {
                padding: 14px 30px;
                font-size: 15px;
              }
            }
          </style>
        </head>
        <body>
          <div class="email-container">
            <div class="header">
              <div class="logo">
                <img src="https://skusers.vercel.app/lovable-uploads/7799326b-6128-47df-9e48-b1abdc4cb85d.png" alt="SK Sure Wins" />
              </div>
              <h1>SK Sure Wins</h1>
              <p>Premium Sports Betting Tips</p>
            </div>
            
            <div class="content">
              <div class="greeting">Reset Your Password 🔐</div>
              
              <p class="message">
                Hello there! 👋<br><br>
                We received a request to reset your password for your SK Sure Wins account. 
                No worries – it happens to the best of us! Click the button below to create a new password and get back to winning.
              </p>
              
              <a href="${resetUrl}" class="reset-button">
                🔑 Reset My Password
              </a>
              
              <div class="security-notice">
                <div class="security-text">
                  <strong>⏰ Important Security Notice:</strong><br>
                  This secure link will expire in <strong>1 hour</strong> for your protection. 
                  If you didn't request this reset, simply ignore this email – your account remains secure.
                </div>
              </div>
              
              <div class="divider"></div>
              
              <p style="color: #6b7280; font-size: 14px; margin-bottom: 15px;">
                Having trouble with the button? Copy and paste this link into your browser:
              </p>
              
              <div class="url-container">
                <div class="url-text">${resetUrl}</div>
              </div>
            </div>
            
            <div class="footer">
              <div class="footer-content">
                <div class="brand-name">SK Sure Wins</div>
                <p class="footer-text">
                  Your trusted partner for premium sports betting tips and strategies.
                </p>
                
                <div class="social-links">
                  <a href="#" class="social-link">📧</a>
                  <a href="#" class="social-link">📱</a>
                  <a href="#" class="social-link">🌐</a>
                </div>
                
                <p style="color: #9ca3af; font-size: 12px; margin-top: 20px;">
                  © 2024 SK Sure Wins. All rights reserved.<br>
                  This email was sent because you requested a password reset.
                </p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log("Password reset email sent successfully:", emailResponse);

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error sending password reset email:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
