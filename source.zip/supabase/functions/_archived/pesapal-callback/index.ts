import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const logError = async (supabase: any, error: any, context: string, params?: any) => {
  try {
    await supabase.from('payment_error_logs').insert({
      error_type: 'CALLBACK_ERROR',
      error_message: JSON.stringify(error),
      error_details: {
        context,
        params,
        stack: error.stack,
        timestamp: new Date().toISOString()
      },
      function_name: 'pesapal-callback'
    });
  } catch (logErr) {
    console.error('❌ Failed to log callback error:', logErr);
  }
};

const getCurrentDomain = (): string => {
  // Always use the production domain for consistency
  const customDomain = Deno.env.get('CUSTOM_DOMAIN');
  if (customDomain) {
    return customDomain;
  }
  return 'https://skusers.vercel.app';
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    console.log('🔄 PesaPal callback received')
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { orderTrackingId, orderMerchantReference, allParams } = await req.json()
    
    console.log('📋 Callback params:', { orderTrackingId, orderMerchantReference })
    console.log('📋 All params:', allParams)

    if (!orderTrackingId && !orderMerchantReference) {
      throw new Error('Missing both orderTrackingId and orderMerchantReference')
    }

    // Use the new database function to find the transaction
    const { data: transactionData, error: transactionError } = await supabaseClient
      .rpc('find_pesapal_transaction', {
        p_order_tracking_id: orderTrackingId,
        p_merchant_reference: orderMerchantReference
      })

    if (transactionError) {
      console.error('❌ Transaction lookup error:', transactionError)
      await logError(supabaseClient, transactionError, 'find_transaction', { orderTrackingId, orderMerchantReference })
      throw new Error('Database error finding transaction')
    }

    if (!transactionData || transactionData.length === 0) {
      console.error('❌ Transaction not found')
      await logError(supabaseClient, 'Transaction not found', 'transaction_not_found', { orderTrackingId, orderMerchantReference })
      throw new Error('Transaction not found')
    }

    const transaction = transactionData[0]
    console.log('📋 Found transaction:', transaction)

    // Check payment status with PesaPal
    const pesapalEnv = Deno.env.get('PESAPAL_ENVIRONMENT') || 'sandbox'
    const baseUrl = pesapalEnv === 'live' 
      ? 'https://pay.pesapal.com/v3/api'
      : 'https://cybqa.pesapal.com/pesapalv3/api'

    // Get auth token
    const authResponse = await fetch(`${baseUrl}/Auth/RequestToken`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        consumer_key: Deno.env.get('PESAPAL_CONSUMER_KEY'),
        consumer_secret: Deno.env.get('PESAPAL_CONSUMER_SECRET')
      })
    })

    if (!authResponse.ok) {
      const authError = `Auth failed: ${authResponse.status} ${authResponse.statusText}`
      console.error('❌', authError)
      await logError(supabaseClient, authError, 'pesapal_auth', { orderTrackingId })
      throw new Error(authError)
    }

    const authData = await authResponse.json()
    console.log('✅ Auth successful')

    // Check transaction status
    const statusResponse = await fetch(
      `${baseUrl}/Transactions/GetTransactionStatus?orderTrackingId=${orderTrackingId}`,
      {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${authData.token}`
        }
      }
    )

    if (!statusResponse.ok) {
      const statusError = `Status check failed: ${statusResponse.status}`
      console.error('❌', statusError)
      await logError(supabaseClient, statusError, 'pesapal_status_check', { orderTrackingId })
      throw new Error(statusError)
    }

    const statusData = await statusResponse.json()
    console.log('📊 Payment status:', statusData)

    // Update transaction record first
    const { error: updateError } = await supabaseClient
      .from('pesapal_transactions')
      .update({
        status: statusData.payment_status_description || statusData.status_code?.toString() || 'unknown',
        payment_status_description: statusData.payment_status_description,
        payment_method: statusData.payment_method,
        pesapal_response: statusData,
        updated_at: new Date().toISOString()
      })
      .eq('id', transaction.id)

    if (updateError) {
      console.error('❌ Failed to update transaction:', updateError)
      await logError(supabaseClient, updateError, 'update_transaction', { 
        transactionId: transaction.id,
        orderTrackingId 
      })
    }

    const currentDomain = getCurrentDomain()
    console.log('🔗 Using domain for redirects:', currentDomain)

    // If payment is successful, create or extend subscription
    if (statusData.payment_status_description === 'Completed' || statusData.status_code === 1) {
      console.log('✅ Payment completed, creating/extending subscription...')
      
      try {
        // Use the new robust subscription function
        const { data: subscriptionResult, error: subscriptionError } = await supabaseClient
          .rpc('extend_or_create_subscription_robust', {
            p_user_id: transaction.user_id,
            p_package_id: transaction.package_id,
            p_payment_reference: orderTrackingId,
            p_duration_days: transaction.package_duration_days || 30
          })

        if (subscriptionError) {
          console.error('❌ Failed to create/extend subscription:', subscriptionError)
          await logError(supabaseClient, subscriptionError, 'create_subscription', { 
            transactionId: transaction.id,
            userId: transaction.user_id,
            packageId: transaction.package_id,
            orderTrackingId 
          })
          
          return new Response(
            JSON.stringify({
              status: 'payment_success_db_error',
              message: 'Your payment went through, but we\'re verifying your subscription. Please refresh or contact support.'
            }),
            {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
              status: 200
            }
          )
        }

        if (!subscriptionResult.success) {
          console.error('❌ Subscription creation failed:', subscriptionResult.error)
          await logError(supabaseClient, subscriptionResult, 'subscription_creation_failed', { 
            transactionId: transaction.id,
            orderTrackingId 
          })
          
          return new Response(
            JSON.stringify({
              status: 'payment_success_db_error',
              message: 'Your payment went through, but we\'re verifying your subscription. Please refresh or contact support.'
            }),
            {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
              status: 200
            }
          )
        }

        console.log('✅ Subscription created/extended successfully:', subscriptionResult)

        // Mark transaction as completed
        await supabaseClient
          .from('pesapal_transactions')
          .update({
            status: 'completed',
            updated_at: new Date().toISOString()
          })
          .eq('id', transaction.id)

        return new Response(
          JSON.stringify({
            status: 'completed',
            message: 'Payment successful! Your subscription is now active.',
            redirect_url: `${currentDomain}/payment-success?status=success&OrderTrackingId=${orderTrackingId}`
          }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200
          }
        )

      } catch (subscriptionException) {
        console.error('💥 Exception in subscription creation:', subscriptionException)
        await logError(supabaseClient, subscriptionException, 'subscription_exception', { 
          transactionId: transaction.id,
          orderTrackingId 
        })
        
        return new Response(
          JSON.stringify({
            status: 'payment_success_db_error',
            message: 'Your payment went through, but we\'re verifying your subscription. Please refresh or contact support.',
            redirect_url: `${currentDomain}/payment-success?status=verifying&OrderTrackingId=${orderTrackingId}`
          }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200
          }
        )
      }
    } else {
      console.log('❌ Payment not completed:', statusData.payment_status_description)
      
      return new Response(
        JSON.stringify({
          status: 'failed',
          message: 'Payment failed',
          redirect_url: `${currentDomain}/payment-cancel?reason=payment_failed`
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200
        }
      )
    }

  } catch (error) {
    console.error('💥 Callback error:', error)
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )
    
    await logError(supabaseClient, error, 'callback_critical_failure')
    
    const currentDomain = getCurrentDomain()
    return new Response(
      JSON.stringify({
        status: 'error',
        message: 'An error occurred while processing your payment.',
        redirect_url: `${currentDomain}/payment-cancel?reason=callback_error`
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    )
  }
})
