import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Simple webhook receiver stub. Configure signature verification once Nylon Pay
// exposes it in the SDK. For now, we update DB state from the payload.
serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const payload = await req.json();
    const reference: string | undefined = payload?.reference || payload?.data?.reference;
    const status: string | undefined = payload?.status || payload?.data?.status;
    if (!reference) throw new Error("Missing reference");

    const normalizedStatus = String(status || "").toLowerCase();
    const finalStatus =
      normalizedStatus === "success" || normalizedStatus === "successful" || normalizedStatus === "completed"
        ? "completed"
        : normalizedStatus === "failed" || normalizedStatus === "cancelled" || normalizedStatus === "expired"
          ? "failed"
          : normalizedStatus || "pending";

    const { data: tx } = await supabase
      .from("nylonpay_transactions")
      .select("id, user_id, package_id, reference, status, metadata")
      .eq("reference", reference)
      .single();

    if (!tx) throw new Error("Transaction not found");
    if (tx.status === "completed") {
      return new Response(JSON.stringify({ success: true, note: "already completed" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    await supabase
      .from("nylonpay_transactions")
      .update({
        status: finalStatus,
        nylonpay_transaction_id: payload?.id ?? payload?.data?.id ?? null,
        metadata: { ...(tx.metadata ?? {}), webhook: payload },
      })
      .eq("id", tx.id);

    if (finalStatus === "completed" && tx.package_id) {
      await supabase.rpc("extend_or_create_subscription_robust", {
        p_user_id: tx.user_id,
        p_package_id: tx.package_id,
        p_payment_reference: reference,
        p_duration_days: Number(tx.metadata?.duration_days) || 30,
      });
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: any) {
    return new Response(
      JSON.stringify({ success: false, error: error?.message ?? "Webhook failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
