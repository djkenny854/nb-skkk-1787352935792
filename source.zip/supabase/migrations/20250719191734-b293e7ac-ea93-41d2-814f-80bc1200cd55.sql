
-- Add notifications table for system messages
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info', -- 'info', 'warning', 'success', 'error'
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE,
  -- If user_id is NULL, it's a broadcast message to all users
  is_broadcast BOOLEAN NOT NULL DEFAULT false
);

-- Add indexes for better performance
CREATE INDEX idx_notifications_user_id ON public.notifications(user_id);
CREATE INDEX idx_notifications_created_at ON public.notifications(created_at DESC);
CREATE INDEX idx_notifications_broadcast ON public.notifications(is_broadcast) WHERE is_broadcast = true;

-- Enable RLS
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Users can view their own notifications and broadcast messages
CREATE POLICY "Users can view own and broadcast notifications" 
  ON public.notifications 
  FOR SELECT 
  USING (auth.uid() = user_id OR is_broadcast = true);

-- Users can update their own notifications (mark as read)
CREATE POLICY "Users can update own notifications" 
  ON public.notifications 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Admins can manage all notifications
CREATE POLICY "Admins can manage notifications" 
  ON public.notifications 
  FOR ALL 
  USING (is_admin(auth.uid()));

-- Add a function to extend existing subscriptions instead of creating new ones
CREATE OR REPLACE FUNCTION extend_or_create_subscription(
  p_user_id UUID,
  p_package_id UUID,
  p_payment_reference TEXT,
  p_duration_days INTEGER
) RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  existing_sub_id UUID;
  new_end_date TIMESTAMP WITH TIME ZONE;
  result_id UUID;
BEGIN
  -- Check for existing active subscription for this package
  SELECT id INTO existing_sub_id
  FROM user_subscriptions
  WHERE user_id = p_user_id 
    AND package_id = p_package_id 
    AND is_active = true 
    AND end_date > NOW();

  IF existing_sub_id IS NOT NULL THEN
    -- Extend existing subscription
    UPDATE user_subscriptions 
    SET end_date = end_date + (p_duration_days || ' days')::INTERVAL,
        updated_at = NOW()
    WHERE id = existing_sub_id
    RETURNING id INTO result_id;
    
    -- Get the new end date for notification
    SELECT end_date INTO new_end_date FROM user_subscriptions WHERE id = existing_sub_id;
    
    -- Create notification for extension
    INSERT INTO notifications (user_id, title, message, type)
    VALUES (
      p_user_id,
      'Subscription Extended! 🎉',
      'Your subscription has been extended by ' || p_duration_days || ' days. New expiry: ' || new_end_date::DATE,
      'success'
    );
  ELSE
    -- Create new subscription
    INSERT INTO user_subscriptions (
      user_id, 
      package_id, 
      start_date, 
      end_date, 
      is_active, 
      payment_reference, 
      payment_method
    ) VALUES (
      p_user_id,
      p_package_id,
      NOW(),
      NOW() + (p_duration_days || ' days')::INTERVAL,
      true,
      p_payment_reference,
      'pesapal'
    ) RETURNING id INTO result_id;
    
    -- Create welcome notification
    INSERT INTO notifications (user_id, title, message, type)
    VALUES (
      p_user_id,
      'Welcome to Premium! 🌟',
      'Your subscription is now active for ' || p_duration_days || ' days. Enjoy premium tips!',
      'success'
    );
  END IF;

  RETURN result_id;
END;
$$;

-- Add function to check subscription expiry and create notifications
CREATE OR REPLACE FUNCTION check_expiring_subscriptions()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Notify users whose subscriptions expire in 2 days
  INSERT INTO notifications (user_id, title, message, type, expires_at)
  SELECT 
    us.user_id,
    'Subscription Expiring Soon ⚠️',
    'Your subscription expires in 2 days on ' || us.end_date::DATE || '. Renew now to keep access!',
    'warning',
    us.end_date
  FROM user_subscriptions us
  LEFT JOIN notifications n ON n.user_id = us.user_id 
    AND n.title LIKE '%Subscription Expiring Soon%' 
    AND n.created_at > NOW() - INTERVAL '1 day'
  WHERE us.is_active = true
    AND us.end_date BETWEEN NOW() + INTERVAL '2 days' AND NOW() + INTERVAL '2 days 1 hour'
    AND n.id IS NULL; -- Don't create duplicate notifications

  -- Notify users whose subscriptions expired today
  INSERT INTO notifications (user_id, title, message, type)
  SELECT 
    us.user_id,
    'Subscription Expired 📭',
    'Your subscription has expired. Subscribe again to continue receiving premium tips!',
    'error'
  FROM user_subscriptions us
  LEFT JOIN notifications n ON n.user_id = us.user_id 
    AND n.title LIKE '%Subscription Expired%' 
    AND n.created_at > NOW() - INTERVAL '1 day'
  WHERE us.is_active = true
    AND us.end_date BETWEEN NOW() - INTERVAL '1 day' AND NOW()
    AND n.id IS NULL;

  -- Deactivate expired subscriptions
  UPDATE user_subscriptions 
  SET is_active = false, updated_at = NOW()
  WHERE is_active = true AND end_date < NOW();
END;
$$;

-- Enable realtime for notifications
ALTER TABLE public.notifications REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;

-- Enable realtime for user_subscriptions to sync payment updates
ALTER TABLE public.user_subscriptions REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_subscriptions;
