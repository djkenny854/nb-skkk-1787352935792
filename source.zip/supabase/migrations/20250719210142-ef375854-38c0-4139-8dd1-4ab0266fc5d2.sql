
-- Create user_devices table for tracking device information
CREATE TABLE public.user_devices (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  os_name TEXT,
  os_version TEXT,
  browser_name TEXT,
  browser_version TEXT,
  device_type TEXT,
  language TEXT,
  ip_address INET,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add Row Level Security
ALTER TABLE public.user_devices ENABLE ROW LEVEL SECURITY;

-- Create policies for user_devices table
CREATE POLICY "Users can view their own devices" 
  ON public.user_devices 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own devices" 
  ON public.user_devices 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can manage all devices" 
  ON public.user_devices 
  FOR ALL 
  USING (is_admin(auth.uid()));

-- Create function to get user's device statistics
CREATE OR REPLACE FUNCTION get_user_device_stats()
RETURNS TABLE (
  total_devices BIGINT,
  mobile_devices BIGINT,
  desktop_devices BIGINT,
  tablet_devices BIGINT,
  unique_browsers BIGINT,
  last_login TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*) as total_devices,
    COUNT(*) FILTER (WHERE device_type = 'Mobile') as mobile_devices,
    COUNT(*) FILTER (WHERE device_type = 'Desktop') as desktop_devices,
    COUNT(*) FILTER (WHERE device_type = 'Tablet') as tablet_devices,
    COUNT(DISTINCT browser_name) as unique_browsers,
    MAX(created_at) as last_login
  FROM user_devices 
  WHERE user_id = auth.uid();
END;
$$;

-- Create function to get all device stats for admins
CREATE OR REPLACE FUNCTION get_all_device_stats()
RETURNS TABLE (
  total_users BIGINT,
  total_devices BIGINT,
  mobile_users BIGINT,
  desktop_users BIGINT,
  tablet_users BIGINT,
  top_browser TEXT,
  top_os TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Access denied. Admin privileges required.';
  END IF;
  
  RETURN QUERY
  SELECT 
    COUNT(DISTINCT user_id) as total_users,
    COUNT(*) as total_devices,
    COUNT(DISTINCT user_id) FILTER (WHERE device_type = 'Mobile') as mobile_users,
    COUNT(DISTINCT user_id) FILTER (WHERE device_type = 'Desktop') as desktop_users,
    COUNT(DISTINCT user_id) FILTER (WHERE device_type = 'Tablet') as tablet_users,
    (SELECT browser_name FROM user_devices GROUP BY browser_name ORDER BY COUNT(*) DESC LIMIT 1) as top_browser,
    (SELECT os_name FROM user_devices GROUP BY os_name ORDER BY COUNT(*) DESC LIMIT 1) as top_os
  FROM user_devices;
END;
$$;
